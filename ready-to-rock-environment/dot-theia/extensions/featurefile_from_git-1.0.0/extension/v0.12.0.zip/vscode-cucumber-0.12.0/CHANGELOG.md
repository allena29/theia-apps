# Changelog

## 0.11

- Continuous Integration. Each commit to `master` triggers a build on Travis. ~~If it succeeds, it publishes a new release in the marketplace.~~

## 0.10

- Rebranding. New logo, new name, new description... all that metadata stuff.

## 0.9

- Gherkin syntax highlight.
- Code snippets. Languages: EN, PT-BR.
